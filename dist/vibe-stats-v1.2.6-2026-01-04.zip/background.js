/**
 * VStateMonitor class handles monitoring of Claude and GitHub Copilot service status
 * Uses Chrome alarms API for reliable background execution
 */
class VStateMonitor {
  constructor() {
    // Claude API endpoints
    this.claude = {
      statusUrl: 'https://status.anthropic.com/api/v2/status.json',
      incidentsUrl: 'https://status.anthropic.com/api/v2/incidents.json',
      summaryUrl: 'https://status.anthropic.com/api/v2/summary.json',
      componentsUrl: 'https://status.anthropic.com/api/v2/components.json'
    };
    
    // GitHub API endpoints
    this.github = {
      statusUrl: 'https://www.githubstatus.com/api/v2/status.json',
      incidentsUrl: 'https://www.githubstatus.com/api/v2/incidents.json',
      summaryUrl: 'https://www.githubstatus.com/api/v2/summary.json',
      componentsUrl: 'https://www.githubstatus.com/api/v2/components.json'
    };
    
    this.alarmName = 'vstateCheck';
    this.intervalMinutes = 5;
    this.maxRetries = 3;
    this.retryDelay = 2000;
    this.animationInterval = null;
    this.animationStartTime = null;
    this.maxAnimationDuration = 30 * 60 * 1000; // 30 minutes max animation
  }

  /**
   * Initialize the VState monitor
   * Sets up alarms for periodic checking
   */
  async init() {
    try {
      // Clear any existing alarm and create new one
      await chrome.alarms.clear(this.alarmName);
      await chrome.alarms.create(this.alarmName, { 
        periodInMinutes: this.intervalMinutes 
      });
      
      // Initial status check for both services
      await this.checkAllStatuses();
    } catch (error) {
      console.error('Failed to initialize VState monitor:', error);
      this.handleError(error, 'initialization');
    }
  }

  /**
   * Check status for Claude and GitHub services
   */
  async checkAllStatuses(retryCount = 0) {
    try {
      const [claudeResults, githubResults] = await Promise.allSettled([
        this.checkServiceStatus('claude'),
        this.checkServiceStatus('github')
      ]);

      // Process results for all services
      const claudeStatus = this.extractStatusFromResult(claudeResults, 'claude');
      const githubStatus = this.extractStatusFromResult(githubResults, 'github');

      // Combine status and determine overall state
      const combinedStatus = this.combineStatuses(claudeStatus, githubStatus);

      // Store the status data
      await this.updateVStateStatus(claudeStatus, githubStatus, combinedStatus);
      await this.updateBadgeIcon(combinedStatus);

      // Store success timestamp
      await chrome.storage.local.set({ lastSuccessfulCheck: Date.now() });

    } catch (error) {
      console.error('Failed to check VState status (attempt', retryCount + 1, '):', error);

      if (retryCount < this.maxRetries) {
        setTimeout(() => this.checkAllStatuses(retryCount + 1), this.retryDelay * (retryCount + 1));
        return;
      }

      // Final failure - set unknown status
      await this.handleCheckFailure(error);
    }
  }

  /**
   * Check status for a specific service (claude or github)
   */
  async checkServiceStatus(serviceName) {
    const serviceConfig = this[serviceName];
    if (!serviceConfig) {
      throw new Error(`Unknown service: ${serviceName}`);
    }

    const [statusData, incidentsData, summaryData] = await Promise.allSettled([
      this.fetchData(serviceConfig.statusUrl),
      this.fetchData(serviceConfig.incidentsUrl),
      this.fetchData(serviceConfig.summaryUrl)
    ]);

    return {
      service: serviceName,
      status: this.extractStatusFromResult(statusData),
      incidents: this.extractIncidentsFromResult(incidentsData),
      components: this.extractComponentsFromResult(summaryData)
    };
  }

  /**
   * Combine statuses from multiple services
   */
  combineStatuses(claudeStatus, githubStatus) {
    // Priority: critical > major > minor > operational
    const statusPriority = {
      'critical': 4,
      'major': 3,
      'minor': 2,
      'operational': 1,
      'unknown': 0
    };

    const claudeLevel = statusPriority[claudeStatus?.status?.indicator] || 0;
    const githubLevel = statusPriority[githubStatus?.status?.indicator] || 0;

    const maxLevel = Math.max(claudeLevel, githubLevel);
    const combinedIndicator = Object.keys(statusPriority).find(key =>
      statusPriority[key] === maxLevel
    ) || 'unknown';

    return {
      indicator: combinedIndicator,
      description: this.getCombinedDescription(claudeStatus, githubStatus, combinedIndicator),
      claude: claudeStatus,
      github: githubStatus
    };
  }

  /**
   * Get combined status description
   */
  getCombinedDescription(claudeStatus, githubStatus, indicator) {
    const descriptions = {
      'operational': 'All dev tools are vibing! 🔥',
      'minor': 'Minor issues detected in your dev tools',
      'major': 'Major issues affecting your dev tools',
      'critical': 'Critical issues - dev tools are down!',
      'unknown': 'Unable to determine dev tools status'
    };

    return descriptions[indicator] || descriptions.unknown;
  }

  /**
   * Fetch data with timeout and proper error handling
   */
  async fetchData(url, timeout = 10000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    
    try {
      const response = await fetch(url, { 
        signal: controller.signal,
        cache: 'no-cache',
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Claude Status Monitor Extension'
        }
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        throw new Error('Request timeout');
      }
      throw error;
    }
  }

  /**
   * Extract status from Promise.allSettled result or service result
   */
  extractStatusFromResult(result, serviceName = null) {
    // Handle service-specific results (from checkServiceStatus)
    if (serviceName && result.status === 'fulfilled' && result.value) {
      return result.value;
    }
    
    // Handle individual API call results  
    if (result.status === 'fulfilled' && result.value?.status?.indicator) {
      return result.value.status.indicator;
    }
    
    return 'unknown';
  }

  /**
   * Extract incidents from Promise.allSettled result
   */
  extractIncidentsFromResult(result) {
    if (result.status === 'fulfilled' && Array.isArray(result.value?.incidents)) {
      return result.value.incidents;
    }
    return [];
  }

  /**
   * Extract components from Promise.allSettled result
   */
  extractComponentsFromResult(result) {
    if (result.status === 'fulfilled' && Array.isArray(result.value?.components)) {
      return result.value.components;
    }
    return [];
  }

  /**
   * Handle check failure with proper error tracking
   */
  async handleCheckFailure(error) {
    await this.updateStatus('unknown', [], [], [], []);
    await this.updateBadgeIcon('unknown', []);
    await chrome.storage.local.set({ 
      lastError: {
        message: error.message,
        timestamp: Date.now()
      }
    });
    this.handleError(error, 'status-check');
  }

  /**
   * Generic error handler with categorization
   */
  handleError(error, category) {
    console.error(`[${category}] Error:`, error);
    // Could integrate with crash reporting service here
  }


  /**
   * Get recent active incidents (unresolved) with formatted titles
   */
  getRecentIncidents(incidents) {
    return incidents
      .filter(incident => incident.status !== 'resolved')
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 5)
      .map(incident => ({
        name: incident.name,
        titleWithDate: this.formatIncidentTitle(incident.name, incident.created_at),
        status: incident.status,
        created_at: incident.created_at,
        shortlink: incident.shortlink,
        impact: incident.impact,
        updates: incident.incident_updates.slice(0, 1).map(update => ({
          body: update.body,
          created_at: update.created_at,
          status: update.status
        }))
      }));
  }

  /**
   * Get last 5 incidents regardless of status with formatted titles
   */
  getLastFiveIncidents(incidents) {
    return incidents
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 5)
      .map(incident => ({
        name: incident.name,
        titleWithDate: this.formatIncidentTitle(incident.name, incident.created_at),
        status: incident.status,
        created_at: incident.created_at,
        resolved_at: incident.resolved_at,
        shortlink: incident.shortlink,
        impact: incident.impact,
        duration: incident.resolved_at ? 
          this.calculateDuration(incident.created_at, incident.resolved_at) : null,
        summary: this.generateIncidentSummary(incident),
        updates: incident.incident_updates.slice(0, 2).map(update => ({
          body: update.body,
          created_at: update.created_at,
          status: update.status
        }))
      }));
  }

  getHistoricalIncidents(incidents) {
    const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
    return incidents
      .filter(incident => new Date(incident.created_at) >= last24Hours)
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 3)
      .map(incident => ({
        name: incident.name,
        status: incident.status,
        created_at: incident.created_at,
        resolved_at: incident.resolved_at,
        impact: incident.impact,
        summary: this.generateIncidentSummary(incident),
        duration: incident.resolved_at ? 
          this.calculateDuration(incident.created_at, incident.resolved_at) : null,
        updates: incident.incident_updates.map(update => ({
          body: update.body,
          created_at: update.created_at,
          status: update.status
        }))
      }));
  }

  generateIncidentSummary(incident) {
    if (!incident.incident_updates || incident.incident_updates.length === 0) {
      return `${incident.impact || 'Minor'} impact incident affecting Claude services.`;
    }
    
    const firstUpdate = incident.incident_updates[incident.incident_updates.length - 1];
    const lastUpdate = incident.incident_updates[0];
    
    let summary = `${incident.impact || 'Minor'} impact: `;
    
    if (incident.status === 'resolved') {
      summary += `Issue resolved. ${lastUpdate.body.slice(0, 100)}...`;
    } else {
      summary += `${firstUpdate.body.slice(0, 100)}...`;
    }
    
    return summary;
  }

  calculateDuration(startTime, endTime) {
    const start = new Date(startTime);
    const end = new Date(endTime);
    const durationMs = end - start;
    const hours = Math.floor(durationMs / (1000 * 60 * 60));
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  }

  /**
   * Format incident title with date
   */
  formatIncidentTitle(name, createdAt) {
    const date = new Date(createdAt);
    const dateStr = date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: date.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined
    });
    const timeStr = date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true
    });
    
    return `${dateStr} ${timeStr} - ${name}`;
  }

  /**
   * Update VState status data in storage
   * Includes pruning to prevent storage accumulation
   */
  async updateVStateStatus(claudeStatus, githubStatus, combinedStatus) {
    const currentTime = new Date().toISOString();
    const maxIncidents = 50; // Limit stored incidents to prevent accumulation

    // Prune incidents to prevent storage bloat
    const claudeIncidents = this.pruneIncidents(claudeStatus?.incidents || [], maxIncidents);
    const githubIncidents = this.pruneIncidents(githubStatus?.incidents || [], maxIncidents);

    await chrome.storage.local.set({
      // Combined status
      vstateStatus: combinedStatus,

      // Individual service data
      claudeStatus: claudeStatus,
      githubStatus: githubStatus,

      // Individual incidents (pruned)
      claudeIncidents: claudeIncidents,
      githubIncidents: githubIncidents,

      // Individual components
      claudeComponents: claudeStatus?.components || [],
      githubComponents: githubStatus?.components || [],

      // Timestamps
      lastUpdated: currentTime,
      lastSuccessfulCheck: Date.now()
    });
  }

  /**
   * Prune incidents array to prevent storage accumulation
   * Keeps the most recent incidents up to maxCount
   */
  pruneIncidents(incidents, maxCount = 50) {
    if (!Array.isArray(incidents)) return [];
    if (incidents.length <= maxCount) return incidents;

    // Sort by created_at descending and take the most recent
    return incidents
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, maxCount);
  }

  async updateStatus(status, incidents, historicalIncidents, components, lastFiveIncidents) {
    await chrome.storage.local.set({
      status: status,
      incidents: incidents,
      historicalIncidents: historicalIncidents || [],
      lastFiveIncidents: lastFiveIncidents || [],
      components: components || [],
      lastUpdated: new Date().toISOString()
    });
  }

  /**
   * Update badge icon with error handling and animation
   */
  async updateBadgeIcon(status, components = []) {
    try {
      const iconPath = this.getIconPath(status);
      
      await chrome.action.setIcon({ path: iconPath });
      
      // Start icon animation for non-operational states
      this.handleIconAnimation(status);

      // Count affected services
      const affectedCount = this.countAffectedServices(components);
      
      let badgeText = '';
      if (status === 'critical') {
        badgeText = affectedCount > 0 ? affectedCount.toString() : '!';
      } else if (status === 'major') {
        badgeText = affectedCount > 0 ? affectedCount.toString() : '!';
      } else if (status === 'minor') {
        badgeText = affectedCount > 0 ? affectedCount.toString() : '?';
      }
      
      await chrome.action.setBadgeText({ text: badgeText });

      if (badgeText) {
        await chrome.action.setBadgeBackgroundColor({
          color: this.getBadgeColor(status)
        });
      }
      
      // Update title with version, status and affected count
      const manifest = chrome.runtime.getManifest();
      const version = manifest.version;
      const statusText = this.getStatusText(status);
      const titleSuffix = affectedCount > 0 ? ` (${affectedCount} affected)` : '';
      await chrome.action.setTitle({
        title: `Vibe Stats v${version} - ${statusText}${titleSuffix}`
      });
      
    } catch (error) {
      console.error('Failed to update badge icon:', error);
    }
  }

  /**
   * Count services that are not operational
   */
  countAffectedServices(components) {
    if (!Array.isArray(components)) return 0;

    // Key service components to track - using word patterns for robust matching
    const keyServicePatterns = [
      /\bclaude\.ai\b/i,
      /\bclaude\s+frontend\b/i,
      /\bclaude\.ai\s+website\b/i,
      /\banthropic\s+console\b/i,
      /\bconsole\.anthropic\.com\b/i,
      /\bconsole\b/i,
      /\banthropic\s+api\b/i,
      /\bapi\.anthropic\.com\b/i,
      /\bapi\s+requests?\b/i,
      /\bclaude\s+code\b/i,
      /\bcode\s+editor\b/i
    ];

    return components.filter(component => {
      const name = component.name;
      const isKeyService = keyServicePatterns.some(pattern => pattern.test(name));
      const isNotOperational = component.status &&
        component.status.toLowerCase() !== 'operational';

      return isKeyService && isNotOperational;
    }).length;
  }

  getIconColor(status) {
    switch (status) {
      case 'none':
      case 'operational':
        return 'green';
      case 'minor':
        return 'yellow';
      case 'major':
      case 'critical':
        return 'red';
      default:
        return 'gray';
    }
  }

  getIconPath(color) {
    return {
      "16": `icons/ai-vibe-16.png`,
      "32": `icons/ai-vibe-32.png`,
      "48": `icons/ai-vibe-48.png`,
      "128": `icons/ai-vibe-128.png`
    };
  }

  /**
   * Handle icon animation for different statuses
   * Includes max duration to prevent indefinite animation
   */
  handleIconAnimation(status) {
    // Clear any existing animation interval
    this.clearAnimation();

    // Start badge animation for problematic statuses instead of icon blinking
    if (status !== 'operational' && status !== 'none') {
      let isVisible = true;
      this.animationStartTime = Date.now();

      this.animationInterval = setInterval(async () => {
        try {
          // Check if max animation duration exceeded
          if (Date.now() - this.animationStartTime > this.maxAnimationDuration) {
            console.log('Animation max duration reached, stopping animation');
            this.clearAnimation();
            // Restore original badge color
            await chrome.action.setBadgeBackgroundColor({
              color: this.getBadgeColor(status)
            });
            return;
          }

          if (isVisible) {
            // Make badge flash by changing opacity
            await chrome.action.setBadgeBackgroundColor({
              color: [255, 0, 0, 100] // Red with low opacity
            });
          } else {
            // Restore original badge color
            await chrome.action.setBadgeBackgroundColor({
              color: this.getBadgeColor(status)
            });
          }
          isVisible = !isVisible;
        } catch (error) {
          console.error('Animation error:', error);
          // If animation fails, clear the interval to prevent spam
          this.clearAnimation();
        }
      }, 1000); // Flash every second
    }
  }

  /**
   * Clear animation interval and reset state
   */
  clearAnimation() {
    if (this.animationInterval) {
      clearInterval(this.animationInterval);
      this.animationInterval = null;
    }
    this.animationStartTime = null;
  }

  getBadgeColor(status) {
    switch (status) {
      case 'none':
      case 'operational':
        return '#4CAF50';
      case 'minor':
        return '#FFC107';
      case 'major':
      case 'critical':
        return '#F44336';
      default:
        return '#9E9E9E';
    }
  }

  /**
   * Get human-readable status text
   */
  getStatusText(status) {
    switch (status) {
      case 'none':
      case 'operational':
        return 'All Systems Operational';
      case 'minor':
        return 'Minor Issues';
      case 'major':
        return 'Major Issues';
      case 'critical':
        return 'Critical Issues';
      default:
        return 'Status Unknown';
    }
  }
}

// Global monitor instance
let vstateMonitor = null;

// Event listeners using modern async patterns
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('VState extension installed/updated:', details.reason);
  try {
    vstateMonitor = new VStateMonitor();
    await vstateMonitor.init();
  } catch (error) {
    console.error('Failed to initialize VState on install:', error);
  }
});

chrome.runtime.onStartup.addListener(async () => {
  console.log('VState extension startup');
  try {
    vstateMonitor = new VStateMonitor();
    await vstateMonitor.init();
  } catch (error) {
    console.error('Failed to initialize VState on startup:', error);
  }
});

// Handle alarm events for periodic checks
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'vstateCheck' && vstateMonitor) {
    await vstateMonitor.checkAllStatuses();
  }
});

// Service worker message handling
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'forceRefresh') {
    (async () => {
      try {
        if (!vstateMonitor) {
          vstateMonitor = new VStateMonitor();
          await vstateMonitor.init();
        }
        await vstateMonitor.checkAllStatuses();
        sendResponse({ status: 'refreshing', timestamp: Date.now() });
      } catch (error) {
        console.error('VState force refresh failed:', error);
        sendResponse({ status: 'error', error: error.message });
      }
    })();
    return true; // Indicates async response
  }
  
  if (message.action === 'getStatus') {
    (async () => {
      try {
        const data = await chrome.storage.local.get([
          'vstateStatus', 'claudeStatus', 'githubStatus',
          'claudeIncidents', 'githubIncidents',
          'lastUpdated', 'lastError'
        ]);
        sendResponse({ status: 'success', data });
      } catch (error) {
        sendResponse({ status: 'error', error: error.message });
      }
    })();
    return true; // Indicates async response
  }
});